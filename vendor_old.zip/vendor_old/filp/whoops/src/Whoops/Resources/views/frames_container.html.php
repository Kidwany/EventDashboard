<div class="frames-container <?php echo $active_frames_tab == 'application' ? 'frames-container-application' : '' ?>">
  <?php $tpl->render($frame_list) ?>
</div>